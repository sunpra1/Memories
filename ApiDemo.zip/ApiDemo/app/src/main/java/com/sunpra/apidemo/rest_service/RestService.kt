package com.sunpra.apidemo.rest_service

import com.sunpra.apidemo.model.Post
import retrofit2.http.GET

interface RestService {
    @GET("posts")
    suspend fun getPosts(): List<Post>
}