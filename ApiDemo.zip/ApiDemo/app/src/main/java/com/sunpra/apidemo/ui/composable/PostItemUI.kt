package com.sunpra.apidemo.ui.composable

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Divider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.sunpra.apidemo.model.Post
import com.sunpra.apidemo.ui.theme.ApiDemoTheme

@Composable
fun PostItemUI(post: Post, modifier: Modifier = Modifier) {
    Box(modifier = modifier.padding(12.dp)) {
        Column {
            Text(text = post.title, style = MaterialTheme.typography.titleMedium)
            Text(text = post.body, style = MaterialTheme.typography.labelMedium)
            Divider()
        }
    }
}

@Composable
@Preview
fun PreviewPostItemUI() {
    ApiDemoTheme {
        PostItemUI(
            Post(
                userId = "1001",
                id = "1",
                title = "This is test title.",
                body = "This is body which is supposed to be very long."
            )
        )
    }
}