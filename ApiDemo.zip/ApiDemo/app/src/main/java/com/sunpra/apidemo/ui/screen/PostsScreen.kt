package com.sunpra.apidemo.ui.screen

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.tooling.preview.Preview
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewmodel.compose.viewModel
import com.sunpra.apidemo.MainActivity
import com.sunpra.apidemo.PostsViewModel
import com.sunpra.apidemo.ui.theme.ApiDemoTheme

@Composable
fun PostsScreen(
    postsViewModel: PostsViewModel = viewModel()
) {
    Scaffold { padding ->
        Box(modifier = Modifier.padding(padding)) {
            LazyColumn {

            }
        }
    }
}

@Preview
@Composable
fun PreviewPosts() {
    ApiDemoTheme {
        PostsScreen()
    }
}