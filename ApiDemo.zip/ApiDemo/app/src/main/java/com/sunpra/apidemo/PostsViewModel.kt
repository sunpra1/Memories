package com.sunpra.apidemo

import androidx.lifecycle.ViewModel

class PostsViewModel: ViewModel() {



}

